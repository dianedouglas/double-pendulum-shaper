#pragma once
#include "CustomViewsFour.h"

class CRafxPluginFactory
{
public:
	static CPlugIn* getRafxPlugIn();
};



