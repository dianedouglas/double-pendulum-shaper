#pragma once
#include <string>

#ifndef __vstguidefs__
#define __vstguidefs__

const std::string DEF_RB_TEXT_SIZE("58, 15");
const std::string DEF_RB_LABEL1_ORIGIN("8, 22");
const std::string DEF_RB_LABEL2_ORIGIN("8, 40");
const std::string DEF_RB_LABEL3_ORIGIN("8, 58");
const std::string DEF_RB_LABEL4_ORIGIN("8, 76");
const std::string DEF_RB_LABEL5_ORIGIN("8, 94");
const std::string DEF_RB_LABEL6_ORIGIN("8, 112");
const std::string DEF_RB_LABEL7_ORIGIN("8, 130");
const std::string DEF_RB_LABEL8_ORIGIN("8, 148");

const std::string DEF_LABEL_SIZE("60, 20");

#endif
